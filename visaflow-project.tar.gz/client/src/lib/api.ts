// API client functions for backend integration

// Admin API
export const adminApi = {
  getBrokers: async () => {
    const response = await fetch("/api/admin/brokers", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch brokers");
    return response.json();
  },

  createBroker: async (data: { name: string; email: string }) => {
    const response = await fetch("/api/admin/brokers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to create broker");
    return response.json();
  },

  updateBrokerStatus: async (brokerId: number, status: string) => {
    const response = await fetch(`/api/admin/brokers/${brokerId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error("Failed to update broker status");
    return response.json();
  },

  getStudents: async () => {
    const response = await fetch("/api/admin/students", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch students");
    return response.json();
  },

  getApplications: async () => {
    const response = await fetch("/api/admin/applications", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch applications");
    return response.json();
  },

  getCommissions: async () => {
    const response = await fetch("/api/admin/commissions", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch commissions");
    return response.json();
  },

  updateCommissionStatus: async (commissionId: number, status: string) => {
    const response = await fetch(`/api/admin/commissions/${commissionId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error("Failed to update commission status");
    return response.json();
  },

  getBroker: async (brokerId: number) => {
    const response = await fetch(`/api/admin/brokers/${brokerId}`, {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch broker");
    return response.json();
  },

  updateBroker: async (brokerId: number, data: any) => {
    const response = await fetch(`/api/admin/brokers/${brokerId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to update broker");
    return response.json();
  },

  getStudent: async (studentId: number) => {
    const response = await fetch(`/api/admin/students/${studentId}`, {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch student");
    return response.json();
  },

  updateStudent: async (studentId: number, data: any) => {
    const response = await fetch(`/api/admin/students/${studentId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to update student");
    return response.json();
  },

  assignBrokerToApplication: async (applicationId: number, brokerId: number) => {
    const response = await fetch(`/api/admin/applications/${applicationId}/assign-broker`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ brokerId }),
    });
    if (!response.ok) throw new Error("Failed to assign broker");
    return response.json();
  },

  getDocuments: async () => {
    const response = await fetch("/api/admin/documents", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch documents");
    return response.json();
  },

  getDocumentsByOwner: async (ownerType: string, ownerId: number) => {
    const response = await fetch(`/api/admin/documents/${ownerType}/${ownerId}`, {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch documents");
    return response.json();
  },
};

// Broker API
export const brokerApi = {
  getStudents: async () => {
    const response = await fetch("/api/broker/students", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch students");
    return response.json();
  },

  createStudent: async (data: { name: string; email: string; visaType: string }) => {
    const response = await fetch("/api/broker/students", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to create student");
    return response.json();
  },

  getApplications: async () => {
    const response = await fetch("/api/broker/applications", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch applications");
    return response.json();
  },

  updateApplicationStatus: async (applicationId: number, status: string) => {
    const response = await fetch(`/api/broker/applications/${applicationId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error("Failed to update application status");
    return response.json();
  },

  getCommissions: async () => {
    const response = await fetch("/api/broker/commissions", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch commissions");
    return response.json();
  },

  getProfile: async () => {
    const response = await fetch("/api/broker/profile", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch profile");
    return response.json();
  },

  updateProfile: async (data: any) => {
    const response = await fetch("/api/broker/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to update profile");
    return response.json();
  },

  getStudentDocuments: async (studentId: number) => {
    const response = await fetch(`/api/broker/students/${studentId}/documents`, {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch documents");
    return response.json();
  },

  updateDocumentStatus: async (documentId: number, status: string, notes?: string) => {
    const response = await fetch(`/api/documents/${documentId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ status, notes }),
    });
    if (!response.ok) throw new Error("Failed to update document status");
    return response.json();
  },
};

// Student API
export const studentApi = {
  getApplications: async () => {
    const response = await fetch("/api/student/applications", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch applications");
    return response.json();
  },

  createApplication: async (data: {
    visaType: string;
    targetCountry: string;
    purpose: string;
    status?: string;
    progress?: number;
    lastAction?: string;
  }) => {
    const response = await fetch("/api/student/applications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to create application");
    return response.json();
  },

  updateApplicationProgress: async (applicationId: number, progress: number, lastAction: string) => {
    const response = await fetch(`/api/student/applications/${applicationId}/progress`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ progress, lastAction }),
    });
    if (!response.ok) throw new Error("Failed to update application progress");
    return response.json();
  },

  getProfile: async () => {
    const response = await fetch("/api/student/profile", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch profile");
    return response.json();
  },

  updateProfile: async (data: any) => {
    const response = await fetch("/api/student/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to update profile");
    return response.json();
  },

  chooseBroker: async (brokerId: number) => {
    const response = await fetch("/api/student/choose-broker", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ brokerId }),
    });
    if (!response.ok) throw new Error("Failed to choose broker");
    return response.json();
  },

  getAssignedBroker: async () => {
    const response = await fetch("/api/student/broker", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch assigned broker");
    return response.json();
  },
};

// Common API
export const commonApi = {
  getAvailableBrokers: async () => {
    const response = await fetch("/api/brokers/available", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch brokers");
    return response.json();
  },

  getActivities: async () => {
    const response = await fetch("/api/activities", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch activities");
    return response.json();
  },

  getMyDocuments: async () => {
    const response = await fetch("/api/documents/my", {
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch documents");
    return response.json();
  },

  uploadDocument: async (data: { ownerType: string; ownerId: number; name: string; type: string; path: string }) => {
    const response = await fetch("/api/documents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to upload document");
    return response.json();
  },

  updateDocumentStatus: async (documentId: number, status: string, notes?: string) => {
    const response = await fetch(`/api/documents/${documentId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ status, notes }),
    });
    if (!response.ok) throw new Error("Failed to update document status");
    return response.json();
  },
};
