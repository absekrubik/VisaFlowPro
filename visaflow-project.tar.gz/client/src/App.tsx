import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth-context";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import LoginPage from "@/pages/auth/login";
import SignupPage from "@/pages/auth/signup";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminBrokers from "@/pages/admin/brokers";
import AdminStudents from "@/pages/admin/students";
import AdminCommissions from "@/pages/admin/commissions";
import AdminSettings from "@/pages/admin/settings";

// Broker Pages
import BrokerDashboard from "@/pages/broker/dashboard";
import BrokerStudents from "@/pages/broker/students";
import BrokerApplications from "@/pages/broker/applications";
import BrokerEarnings from "@/pages/broker/earnings";
import BrokerProfile from "@/pages/broker/profile";

// Student Pages
import StudentDashboard from "@/pages/student/dashboard";
import StudentApplication from "@/pages/student/application";
import StudentBrokerInfo from "@/pages/student/broker-info";
import StudentProfile from "@/pages/student/profile";
import StudentDocuments from "@/pages/student/documents";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={LoginPage} />
      <Route path="/signup" component={SignupPage} />
      
      {/* Admin Routes */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/brokers" component={AdminBrokers} />
      <Route path="/admin/students" component={AdminStudents} />
      <Route path="/admin/commissions" component={AdminCommissions} />
      <Route path="/admin/settings" component={AdminSettings} />
      
      {/* Broker Routes */}
      <Route path="/broker" component={BrokerDashboard} />
      <Route path="/broker/students" component={BrokerStudents} />
      <Route path="/broker/applications" component={BrokerApplications} />
      <Route path="/broker/earnings" component={BrokerEarnings} />
      <Route path="/broker/profile" component={BrokerProfile} />
      
      {/* Student Routes */}
      <Route path="/student" component={StudentDashboard} />
      <Route path="/student/application" component={StudentApplication} />
      <Route path="/student/broker" component={StudentBrokerInfo} />
      <Route path="/student/profile" component={StudentProfile} />
      <Route path="/student/documents" component={StudentDocuments} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;
