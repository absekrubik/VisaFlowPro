import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, MoreHorizontal, Edit, Percent } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { adminApi } from "@/lib/api";

export default function AdminBrokers() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedBroker, setSelectedBroker] = useState<any>(null);
  const [editForm, setEditForm] = useState({ commissionRate: "", phone: "", companyName: "" });
  const [newBroker, setNewBroker] = useState({ name: "", email: "" });

  const { data: brokers = [], isLoading } = useQuery({
    queryKey: ["admin", "brokers"],
    queryFn: adminApi.getBrokers,
  });

  const createMutation = useMutation({
    mutationFn: adminApi.createBroker,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "brokers"] });
      setIsAddOpen(false);
      setNewBroker({ name: "", email: "" });
      toast({ title: "Broker Added", description: `${newBroker.name} has been added to the system.` });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add broker",
        variant: "destructive" 
      });
    },
  });

  const statusMutation = useMutation({
    mutationFn: ({ brokerId, status }: { brokerId: number; status: string }) =>
      adminApi.updateBrokerStatus(brokerId, status),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["admin", "brokers"] });
      toast({ title: "Status Updated", description: `Broker status changed to ${variables.status}.` });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update status",
        variant: "destructive" 
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ brokerId, data }: { brokerId: number; data: any }) =>
      adminApi.updateBroker(brokerId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "brokers"] });
      setIsEditOpen(false);
      setSelectedBroker(null);
      toast({ title: "Broker Updated", description: "Broker details have been updated." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update broker",
        variant: "destructive" 
      });
    },
  });

  const openEditDialog = (broker: any) => {
    setSelectedBroker(broker);
    setEditForm({
      commissionRate: broker.commissionRate?.replace("%", "") || "10",
      phone: broker.phone || "",
      companyName: broker.companyName || "",
    });
    setIsEditOpen(true);
  };

  const handleUpdateBroker = () => {
    if (!selectedBroker) return;
    const data: any = {};
    if (editForm.commissionRate) data.commissionRate = `${editForm.commissionRate}%`;
    if (editForm.phone) data.phone = editForm.phone;
    if (editForm.companyName) data.companyName = editForm.companyName;
    updateMutation.mutate({ brokerId: selectedBroker.id, data });
  };

  const handleAddBroker = () => {
    if (!newBroker.name || !newBroker.email) {
      toast({ title: "Error", description: "Please fill in all fields", variant: "destructive" });
      return;
    }
    createMutation.mutate(newBroker);
  };

  const toggleStatus = (broker: any) => {
    const newStatus = broker.status === "Active" ? "Inactive" : "Active";
    statusMutation.mutate({ brokerId: broker.id, status: newStatus });
  };

  if (isLoading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Loading brokers...</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Manage Brokers</h1>
          <p className="text-muted-foreground">Add, edit, and manage your visa consultants.</p>
        </div>
        
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" /> Add Broker
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-white/10">
            <DialogHeader>
              <DialogTitle>Add New Broker</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input 
                  placeholder="Jane Doe" 
                  className="bg-white/5 border-white/10"
                  value={newBroker.name}
                  onChange={(e) => setNewBroker({...newBroker, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Email Address</Label>
                <Input 
                  placeholder="jane@visaflow.com" 
                  className="bg-white/5 border-white/10"
                  value={newBroker.email}
                  onChange={(e) => setNewBroker({...newBroker, email: e.target.value})}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsAddOpen(false)}>Cancel</Button>
              <Button onClick={handleAddBroker}>Create Account</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="glass-panel border-white/5">
        <CardHeader>
          <CardTitle>All Brokers</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-white/10 hover:bg-white/5">
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Active Students</TableHead>
                <TableHead>Commission Rate</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {brokers.map((broker: any) => (
                <TableRow key={broker.id} className="border-white/10 hover:bg-white/5">
                  <TableCell className="font-medium">{broker.user?.name || "N/A"}</TableCell>
                  <TableCell>{broker.user?.email || "N/A"}</TableCell>
                  <TableCell>{broker.activeStudents}</TableCell>
                  <TableCell>{broker.commissionRate}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={broker.status === "Active" ? "bg-green-500/10 text-green-500 border-green-500/20" : "bg-gray-500/10 text-gray-500 border-gray-500/20"}>
                      {broker.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-card border-white/10">
                        <DropdownMenuItem onClick={() => openEditDialog(broker)} data-testid={`edit-broker-${broker.id}`}>
                          <Edit className="w-4 h-4 mr-2" /> Edit Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast({ title: "Performance", description: "Opening performance metrics..." })}>
                          View Performance
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className={broker.status === "Active" ? "text-destructive" : "text-green-500"}
                          onClick={() => toggleStatus(broker)}
                        >
                          {broker.status === "Active" ? "Deactivate" : "Activate"}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-card border-white/10">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Percent className="w-5 h-5" /> Edit Broker Details
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-3 bg-white/5 rounded-lg mb-4">
              <p className="text-sm text-muted-foreground">Editing: <span className="text-white font-medium">{selectedBroker?.user?.name}</span></p>
            </div>
            <div className="space-y-2">
              <Label>Commission Rate (%)</Label>
              <div className="relative">
                <Input 
                  type="number"
                  min="0"
                  max="100"
                  placeholder="10" 
                  className="bg-white/5 border-white/10 pr-8"
                  value={editForm.commissionRate}
                  onChange={(e) => setEditForm({...editForm, commissionRate: e.target.value})}
                  data-testid="input-commission-rate"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input 
                placeholder="+1 234 567 8900" 
                className="bg-white/5 border-white/10"
                value={editForm.phone}
                onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                data-testid="input-broker-phone"
              />
            </div>
            <div className="space-y-2">
              <Label>Company Name</Label>
              <Input 
                placeholder="Visa Consultants Inc." 
                className="bg-white/5 border-white/10"
                value={editForm.companyName}
                onChange={(e) => setEditForm({...editForm, companyName: e.target.value})}
                data-testid="input-broker-company"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsEditOpen(false)} data-testid="cancel-edit-broker">Cancel</Button>
            <Button onClick={handleUpdateBroker} disabled={updateMutation.isPending} data-testid="save-broker-changes">
              {updateMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
