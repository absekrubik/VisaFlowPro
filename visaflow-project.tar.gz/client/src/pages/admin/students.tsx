import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, MoreHorizontal, UserPlus, UserMinus, Users } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { adminApi } from "@/lib/api";

export default function AdminStudents() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [selectedBrokerId, setSelectedBrokerId] = useState<string>("");

  const { data: students = [], isLoading } = useQuery({
    queryKey: ["admin", "students"],
    queryFn: adminApi.getStudents,
  });

  const { data: brokers = [] } = useQuery({
    queryKey: ["admin", "brokers"],
    queryFn: adminApi.getBrokers,
  });

  const activeBrokers = brokers.filter((b: any) => b.status === "Active");

  const updateStudentMutation = useMutation({
    mutationFn: ({ studentId, data }: { studentId: number; data: any }) =>
      adminApi.updateStudent(studentId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "students"] });
      queryClient.invalidateQueries({ queryKey: ["admin", "brokers"] });
      setIsAssignOpen(false);
      setSelectedStudent(null);
      setSelectedBrokerId("");
      toast({ title: "Student Updated", description: "Broker assignment has been updated." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update student",
        variant: "destructive" 
      });
    },
  });

  const openAssignDialog = (student: any) => {
    setSelectedStudent(student);
    setSelectedBrokerId(student.brokerId?.toString() || "");
    setIsAssignOpen(true);
  };

  const handleAssignBroker = () => {
    if (!selectedStudent) return;
    const brokerId = selectedBrokerId === "none" ? null : parseInt(selectedBrokerId);
    updateStudentMutation.mutate({ 
      studentId: selectedStudent.id, 
      data: { brokerId } 
    });
  };

  const handleRemoveBroker = (student: any) => {
    updateStudentMutation.mutate({ 
      studentId: student.id, 
      data: { brokerId: null } 
    });
  };

  const filteredStudents = students.filter((student: any) => 
    student.user?.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    student.user?.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Loading students...</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Student Management</h1>
          <p className="text-muted-foreground">View and manage all registered students.</p>
        </div>
      </div>

      <div className="flex items-center space-x-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1 max-w-md">
        <Search className="w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search by name or email..." 
          className="border-none bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0" 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          data-testid="input-search-students"
        />
      </div>

      <Card className="glass-panel border-white/5">
        <CardHeader>
          <CardTitle>All Students ({filteredStudents.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-white/10 hover:bg-white/5">
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Assigned Broker</TableHead>
                <TableHead>Passport Number</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground">
                    No students found
                  </TableCell>
                </TableRow>
              ) : (
                filteredStudents.map((student: any) => (
                  <TableRow key={student.id} className="border-white/10 hover:bg-white/5" data-testid={`row-student-${student.id}`}>
                    <TableCell className="font-medium" data-testid={`text-student-name-${student.id}`}>
                      {student.user?.name || "N/A"}
                    </TableCell>
                    <TableCell data-testid={`text-student-email-${student.id}`}>
                      {student.user?.email || "N/A"}
                    </TableCell>
                    <TableCell>
                      {student.broker ? (
                        <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20" data-testid={`badge-broker-${student.id}`}>
                          {student.broker.user?.name}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-gray-500/10 text-gray-500 border-gray-500/20" data-testid={`badge-unassigned-${student.id}`}>
                          Unassigned
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{student.passportNumber || "Not provided"}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8" data-testid={`menu-student-${student.id}`}>
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-card border-white/10">
                          <DropdownMenuItem 
                            onClick={() => openAssignDialog(student)}
                            data-testid={`action-assign-broker-${student.id}`}
                          >
                            <UserPlus className="w-4 h-4 mr-2" />
                            {student.brokerId ? "Change Broker" : "Assign Broker"}
                          </DropdownMenuItem>
                          {student.brokerId && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleRemoveBroker(student)}
                                className="text-destructive"
                                data-testid={`action-remove-broker-${student.id}`}
                              >
                                <UserMinus className="w-4 h-4 mr-2" />
                                Remove Broker
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
        <DialogContent className="bg-card border-white/10">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" /> Assign Broker
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-3 bg-white/5 rounded-lg">
              <p className="text-sm text-muted-foreground">
                Student: <span className="text-white font-medium">{selectedStudent?.user?.name}</span>
              </p>
              {selectedStudent?.broker && (
                <p className="text-sm text-muted-foreground mt-1">
                  Current Broker: <span className="text-primary font-medium">{selectedStudent.broker.user?.name}</span>
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>Select Broker</Label>
              <Select value={selectedBrokerId} onValueChange={setSelectedBrokerId}>
                <SelectTrigger className="bg-white/5 border-white/10" data-testid="select-broker-assignment">
                  <SelectValue placeholder="Choose a broker" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Broker (Unassign)</SelectItem>
                  {activeBrokers.map((broker: any) => (
                    <SelectItem key={broker.id} value={broker.id.toString()}>
                      {broker.user?.name} ({broker.activeStudents} students)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsAssignOpen(false)} data-testid="cancel-assign-broker">
              Cancel
            </Button>
            <Button 
              onClick={handleAssignBroker} 
              disabled={updateStudentMutation.isPending}
              data-testid="confirm-assign-broker"
            >
              {updateStudentMutation.isPending ? "Saving..." : "Save Assignment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
