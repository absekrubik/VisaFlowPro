import mongoose from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  throw new Error(
    "MONGODB_URI must be set. Did you forget to add a MongoDB connection string?",
  );
}

let isConnected = false;

export async function connectToDatabase(): Promise<typeof mongoose> {
  if (isConnected) {
    return mongoose;
  }

  try {
    await mongoose.connect(MONGODB_URI as string);
    isConnected = true;
    console.log("Connected to MongoDB");
    return mongoose;
  } catch (error) {
    console.error("MongoDB connection error:", error);
    throw error;
  }
}

const counterSchema = new mongoose.Schema({
  _id: { type: String, required: true },
  seq: { type: Number, default: 0 }
});

const Counter = mongoose.models.Counter || mongoose.model("Counter", counterSchema);

export async function getNextSequence(name: string): Promise<number> {
  const counter = await Counter.findByIdAndUpdate(
    name,
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );
  return counter.seq;
}

const userSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["admin", "broker", "student"], required: true },
  createdAt: { type: Date, default: Date.now },
});

const brokerSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: true },
  commissionRate: { type: String, default: "10%" },
  status: { type: String, default: "Active" },
  activeStudents: { type: Number, default: 0 },
  phone: { type: String },
  address: { type: String },
  companyName: { type: String },
  licenseNumber: { type: String },
});

const studentSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: true },
  brokerId: { type: Number, default: null },
  passportNumber: { type: String },
  dateOfBirth: { type: String },
  currentAddress: { type: String },
  phone: { type: String },
  nationality: { type: String },
  education: { type: String },
});

const applicationSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  studentId: { type: Number, required: true },
  visaType: { type: String, required: true },
  targetCountry: { type: String, required: true },
  purpose: { type: String },
  status: { type: String, enum: ["Document Review", "Submitted", "Interview", "Approved", "Rejected"], default: "Document Review" },
  progress: { type: Number, default: 0 },
  submittedAt: { type: Date, default: Date.now },
  lastAction: { type: String },
});

const commissionSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  brokerId: { type: Number, required: true },
  studentId: { type: Number, required: true },
  amount: { type: String, required: true },
  status: { type: String, enum: ["Pending", "Approved", "Paid", "Rejected"], default: "Pending" },
  date: { type: Date, default: Date.now },
});

const documentSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  ownerType: { type: String, enum: ["admin", "broker", "student"], required: true },
  ownerId: { type: Number, required: true },
  uploadedById: { type: Number, required: true },
  name: { type: String, required: true },
  type: { type: String, required: true },
  path: { type: String, required: true },
  status: { type: String, enum: ["Pending", "Approved", "Rejected"], default: "Pending" },
  notes: { type: String },
  uploadedAt: { type: Date, default: Date.now },
});

const activitySchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  actorId: { type: Number, required: true },
  actorRole: { type: String, enum: ["admin", "broker", "student"], required: true },
  targetType: { type: String, required: true },
  targetId: { type: Number, required: true },
  activityType: { type: String, enum: ["application_submitted", "application_updated", "broker_assigned", "document_uploaded", "document_reviewed", "commission_created", "profile_updated", "status_changed"], required: true },
  description: { type: String, required: true },
  metadata: { type: mongoose.Schema.Types.Mixed },
  createdAt: { type: Date, default: Date.now },
});

export const UserModel = mongoose.models.User || mongoose.model("User", userSchema);
export const BrokerModel = mongoose.models.Broker || mongoose.model("Broker", brokerSchema);
export const StudentModel = mongoose.models.Student || mongoose.model("Student", studentSchema);
export const ApplicationModel = mongoose.models.Application || mongoose.model("Application", applicationSchema);
export const CommissionModel = mongoose.models.Commission || mongoose.model("Commission", commissionSchema);
export const DocumentModel = mongoose.models.Document || mongoose.model("Document", documentSchema);
export const ActivityModel = mongoose.models.Activity || mongoose.model("Activity", activitySchema);
