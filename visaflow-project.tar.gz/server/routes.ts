import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertApplicationSchema, updateStudentSchema, updateBrokerSchema } from "@shared/schema";
import bcrypt from "bcryptjs";
import crypto from "crypto";

function generateSecurePassword(): string {
  return crypto.randomBytes(16).toString('base64');
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { name, email, password, role } = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      
      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        role,
      });

      if (role === "broker") {
        await storage.createBroker({
          userId: user.id,
          commissionRate: "10%",
          status: "Active",
        });
      } else if (role === "student") {
        await storage.createStudent({
          userId: user.id,
          brokerId: null,
        });
      }

      req.session.userId = user.id;
      req.session.role = role;

      res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    } catch (error: any) {
      console.error("Signup error:", error);
      res.status(400).json({ error: error.message || "Signup failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password, role } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user || user.role !== role) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.userId = user.id;
      req.session.role = user.role;

      res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(400).json({ error: error.message || "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err: any) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const user = await storage.getUserById(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  });

  // Admin routes
  app.get("/api/admin/brokers", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const brokers = await storage.getAllBrokers();
    res.json(brokers);
  });

  app.post("/api/admin/brokers", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { name, email } = req.body;
      const password = generateSecurePassword();
      const hashedPassword = await bcrypt.hash(password, 10);

      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        role: "broker",
      });

      const broker = await storage.createBroker({
        userId: user.id,
        commissionRate: "10%",
        status: "Active",
      });

      res.json({ ...broker, user, temporaryPassword: password });
    } catch (error: any) {
      console.error("Create broker error:", error);
      res.status(400).json({ error: error.message || "Failed to create broker" });
    }
  });

  app.patch("/api/admin/brokers/:id/status", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { status } = req.body;
      await storage.updateBrokerStatus(parseInt(req.params.id), status);
      res.json({ message: "Status updated" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/admin/students", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const students = await storage.getAllStudents();
    res.json(students);
  });

  app.get("/api/admin/applications", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const applications = await storage.getAllApplications();
    res.json(applications);
  });

  app.get("/api/admin/commissions", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const commissions = await storage.getAllCommissions();
    res.json(commissions);
  });

  app.patch("/api/admin/commissions/:id/status", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { status } = req.body;
      await storage.updateCommissionStatus(parseInt(req.params.id), status);
      res.json({ message: "Status updated" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Broker routes
  app.get("/api/broker/students", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const broker = await storage.getBrokerByUserId(req.session.userId!);
    if (!broker) {
      return res.status(404).json({ error: "Broker not found" });
    }

    const students = await storage.getStudentsByBrokerId(broker.id);
    res.json(students);
  });

  app.post("/api/broker/students", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { name, email, visaType } = req.body;
      const password = generateSecurePassword();
      const hashedPassword = await bcrypt.hash(password, 10);

      const broker = await storage.getBrokerByUserId(req.session.userId!);
      if (!broker) {
        return res.status(404).json({ error: "Broker not found" });
      }

      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        role: "student",
      });

      const student = await storage.createStudent({
        userId: user.id,
        brokerId: broker.id,
      });

      await storage.createApplication({
        studentId: student.id,
        visaType: visaType || "F-1 Student",
        targetCountry: "United States",
        purpose: "",
        status: "Document Review",
        progress: 0,
        lastAction: "Account Created",
      });

      res.json({ ...student, user, temporaryPassword: password });
    } catch (error: any) {
      console.error("Create student error:", error);
      res.status(400).json({ error: error.message || "Failed to create student" });
    }
  });

  app.get("/api/broker/applications", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const broker = await storage.getBrokerByUserId(req.session.userId!);
    if (!broker) {
      return res.status(404).json({ error: "Broker not found" });
    }

    const applications = await storage.getApplicationsByBrokerId(broker.id);
    res.json(applications);
  });

  app.patch("/api/broker/applications/:id/status", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { status } = req.body;
      await storage.updateApplicationStatus(parseInt(req.params.id), status);
      res.json({ message: "Status updated" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/broker/commissions", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const broker = await storage.getBrokerByUserId(req.session.userId!);
    if (!broker) {
      return res.status(404).json({ error: "Broker not found" });
    }

    const commissions = await storage.getCommissionsByBrokerId(broker.id);
    res.json(commissions);
  });

  // Student routes
  app.get("/api/student/applications", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const student = await storage.getStudentByUserId(req.session.userId!);
    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }

    const applications = await storage.getApplicationsByStudentId(student.id);
    res.json(applications);
  });

  app.post("/api/student/applications", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const student = await storage.getStudentByUserId(req.session.userId!);
      if (!student) {
        return res.status(404).json({ error: "Student not found" });
      }

      const applicationData = insertApplicationSchema.parse({
        visaType: req.body.visaType,
        targetCountry: req.body.targetCountry,
        purpose: req.body.purpose || "",
        studentId: student.id,
        status: "Document Review",
        progress: 10,
        lastAction: "Application Submitted",
      });

      const application = await storage.createApplication(applicationData);
      res.json(application);
    } catch (error: any) {
      console.error("Create application error:", error);
      res.status(400).json({ error: error.message || "Failed to create application" });
    }
  });

  app.patch("/api/student/applications/:id/progress", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { progress, lastAction } = req.body;
      await storage.updateApplicationProgress(parseInt(req.params.id), progress, lastAction);
      res.json({ message: "Progress updated" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/student/profile", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const student = await storage.getStudentByUserId(req.session.userId!);
    const user = await storage.getUserById(req.session.userId!);
    
    // Include broker info if assigned
    let broker = null;
    let brokerUser = null;
    if (student?.brokerId) {
      broker = await storage.getBrokerById(student.brokerId);
      if (broker) {
        brokerUser = await storage.getUserById(broker.userId);
      }
    }
    
    res.json({ ...student, user, broker: broker ? { ...broker, user: brokerUser } : null });
  });

  // Get assigned broker info for student
  app.get("/api/student/broker", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const student = await storage.getStudentByUserId(req.session.userId!);
    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }

    if (!student.brokerId) {
      return res.json({ broker: null });
    }

    const broker = await storage.getBrokerById(student.brokerId);
    if (!broker) {
      return res.json({ broker: null });
    }

    const brokerUser = await storage.getUserById(broker.userId);
    res.json({ broker: { ...broker, user: brokerUser } });
  });

  app.patch("/api/student/profile", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const student = await storage.getStudentByUserId(req.session.userId!);
      if (!student) {
        return res.status(404).json({ error: "Student not found" });
      }

      const updateData = updateStudentSchema.parse(req.body);
      const updatedStudent = await storage.updateStudentProfile(student.id, updateData);
      
      if (req.body.name) {
        await storage.updateUserName(req.session.userId!, req.body.name);
      }

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: "student",
        targetType: "student",
        targetId: student.id,
        activityType: "profile_updated",
        description: `Student profile updated`,
        metadata: {},
      });

      res.json(updatedStudent);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/student/choose-broker", async (req, res) => {
    if (req.session.role !== "student") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const student = await storage.getStudentByUserId(req.session.userId!);
      if (!student) {
        return res.status(404).json({ error: "Student not found" });
      }

      const { brokerId } = req.body;
      await storage.assignBrokerToStudent(student.id, brokerId);

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: "student",
        targetType: "broker",
        targetId: brokerId,
        activityType: "broker_assigned",
        description: `Student chose a broker`,
        metadata: { studentId: student.id },
      });

      res.json({ message: "Broker assigned successfully" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Broker profile routes
  app.get("/api/broker/profile", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const broker = await storage.getBrokerByUserId(req.session.userId!);
    const user = await storage.getUserById(req.session.userId!);
    res.json({ ...broker, user });
  });

  app.patch("/api/broker/profile", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const broker = await storage.getBrokerByUserId(req.session.userId!);
      if (!broker) {
        return res.status(404).json({ error: "Broker not found" });
      }

      const updateData = updateBrokerSchema.parse(req.body);
      const updatedBroker = await storage.updateBrokerProfile(broker.id, updateData);
      
      if (req.body.name) {
        await storage.updateUserName(req.session.userId!, req.body.name);
      }

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: "broker",
        targetType: "broker",
        targetId: broker.id,
        activityType: "profile_updated",
        description: `Broker profile updated`,
        metadata: {},
      });

      res.json(updatedBroker);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Admin routes for managing brokers and students
  app.patch("/api/admin/brokers/:id", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const brokerId = parseInt(req.params.id);
      const broker = await storage.getBrokerById(brokerId);
      if (!broker) {
        return res.status(404).json({ error: "Broker not found" });
      }

      const updateData: any = {};
      if (req.body.commissionRate) updateData.commissionRate = req.body.commissionRate;
      if (req.body.status) updateData.status = req.body.status;
      if (req.body.phone) updateData.phone = req.body.phone;
      if (req.body.address) updateData.address = req.body.address;
      if (req.body.companyName) updateData.companyName = req.body.companyName;
      if (req.body.licenseNumber) updateData.licenseNumber = req.body.licenseNumber;

      const updatedBroker = await storage.updateBrokerProfile(brokerId, updateData);
      
      if (req.body.name) {
        await storage.updateUserName(broker.userId, req.body.name);
      }

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: "admin",
        targetType: "broker",
        targetId: brokerId,
        activityType: "profile_updated",
        description: `Admin updated broker profile`,
        metadata: { changes: Object.keys(updateData) },
      });

      res.json(updatedBroker);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/admin/brokers/:id", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const broker = await storage.getBrokerById(parseInt(req.params.id));
    if (!broker) {
      return res.status(404).json({ error: "Broker not found" });
    }

    const user = await storage.getUserById(broker.userId);
    res.json({ ...broker, user });
  });

  app.patch("/api/admin/students/:id", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const studentId = parseInt(req.params.id);
      const student = await storage.getStudentById(studentId);
      if (!student) {
        return res.status(404).json({ error: "Student not found" });
      }

      const updateData: any = {};
      if (req.body.passportNumber) updateData.passportNumber = req.body.passportNumber;
      if (req.body.dateOfBirth) updateData.dateOfBirth = req.body.dateOfBirth;
      if (req.body.currentAddress) updateData.currentAddress = req.body.currentAddress;
      if (req.body.phone) updateData.phone = req.body.phone;
      if (req.body.nationality) updateData.nationality = req.body.nationality;
      if (req.body.education) updateData.education = req.body.education;
      if (req.body.brokerId !== undefined) updateData.brokerId = req.body.brokerId;

      const updatedStudent = await storage.updateStudentProfile(studentId, updateData);
      
      if (req.body.name) {
        await storage.updateUserName(student.userId, req.body.name);
      }

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: "admin",
        targetType: "student",
        targetId: studentId,
        activityType: "profile_updated",
        description: `Admin updated student profile`,
        metadata: { changes: Object.keys(updateData) },
      });

      res.json(updatedStudent);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/admin/students/:id", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const student = await storage.getStudentById(parseInt(req.params.id));
    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }

    const user = await storage.getUserById(student.userId);
    res.json({ ...student, user });
  });

  app.patch("/api/admin/applications/:id/assign-broker", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { brokerId } = req.body;
      const applicationId = parseInt(req.params.id);
      
      const application = await storage.getApplicationById(applicationId);
      if (!application) {
        return res.status(404).json({ error: "Application not found" });
      }

      await storage.assignBrokerToStudent(application.studentId, brokerId);

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: "admin",
        targetType: "application",
        targetId: applicationId,
        activityType: "broker_assigned",
        description: `Admin assigned broker to student`,
        metadata: { brokerId, studentId: application.studentId },
      });

      res.json({ message: "Broker assigned successfully" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Helper function to validate URLs
  const isValidDocumentUrl = (url: string): boolean => {
    try {
      const parsed = new URL(url);
      return parsed.protocol === "https:" || parsed.protocol === "http:";
    } catch {
      return false;
    }
  };

  // Document routes
  app.post("/api/documents", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    try {
      const { ownerType, ownerId, name, type, path } = req.body;
      
      // Validate URL to prevent XSS - only allow http/https
      if (!path || !isValidDocumentUrl(path)) {
        return res.status(400).json({ error: "Invalid document URL. Only http:// and https:// URLs are allowed." });
      }
      
      const document = await storage.createDocument({
        ownerType,
        ownerId,
        uploadedById: req.session.userId,
        name,
        type,
        path,
        status: "Pending",
      });

      await storage.createActivity({
        actorId: req.session.userId,
        actorRole: req.session.role!,
        targetType: ownerType,
        targetId: ownerId,
        activityType: "document_uploaded",
        description: `Document "${name}" uploaded`,
        metadata: { documentId: document.id },
      });

      res.json(document);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/documents/my", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    let ownerId: number;
    let ownerType: string;

    if (req.session.role === "student") {
      const student = await storage.getStudentByUserId(req.session.userId);
      if (!student) return res.status(404).json({ error: "Student not found" });
      ownerId = student.id;
      ownerType = "student";
    } else if (req.session.role === "broker") {
      const broker = await storage.getBrokerByUserId(req.session.userId);
      if (!broker) return res.status(404).json({ error: "Broker not found" });
      ownerId = broker.id;
      ownerType = "broker";
    } else {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const documents = await storage.getDocumentsByOwner(ownerType, ownerId);
    res.json(documents);
  });

  app.get("/api/broker/students/:studentId/documents", async (req, res) => {
    if (req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const broker = await storage.getBrokerByUserId(req.session.userId!);
    if (!broker) {
      return res.status(404).json({ error: "Broker not found" });
    }

    const studentId = parseInt(req.params.studentId);
    const student = await storage.getStudentById(studentId);
    
    if (!student || student.brokerId !== broker.id) {
      return res.status(403).json({ error: "Student not assigned to you" });
    }

    const documents = await storage.getDocumentsByOwner("student", studentId);
    res.json(documents);
  });

  app.get("/api/admin/documents", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const documents = await storage.getAllDocuments();
    res.json(documents);
  });

  app.get("/api/admin/documents/:ownerType/:ownerId", async (req, res) => {
    if (req.session.role !== "admin") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const documents = await storage.getDocumentsByOwner(req.params.ownerType, parseInt(req.params.ownerId));
    res.json(documents);
  });

  app.patch("/api/documents/:id/status", async (req, res) => {
    if (req.session.role !== "admin" && req.session.role !== "broker") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { status, notes } = req.body;
      const documentId = parseInt(req.params.id);

      // For brokers, verify they have access to this document's owner
      if (req.session.role === "broker") {
        const broker = await storage.getBrokerByUserId(req.session.userId!);
        if (!broker) {
          return res.status(404).json({ error: "Broker not found" });
        }
        
        const document = await storage.getDocumentById(documentId);
        if (!document) {
          return res.status(404).json({ error: "Document not found" });
        }
        
        // Only allow brokers to update documents of their assigned students
        if (document.ownerType === "student") {
          const student = await storage.getStudentById(document.ownerId);
          if (!student || student.brokerId !== broker.id) {
            return res.status(403).json({ error: "You can only manage documents from your assigned students" });
          }
        } else {
          return res.status(403).json({ error: "Unauthorized to manage this document" });
        }
      }

      await storage.updateDocumentStatus(documentId, status, notes);

      await storage.createActivity({
        actorId: req.session.userId!,
        actorRole: req.session.role,
        targetType: "document",
        targetId: documentId,
        activityType: "document_reviewed",
        description: `Document status updated to ${status}`,
        metadata: { status, notes },
      });

      res.json({ message: "Document status updated" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Activity/Notification routes
  app.get("/api/activities", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    let activities;
    if (req.session.role === "admin") {
      activities = await storage.getAllActivities();
    } else {
      activities = await storage.getActivitiesByRole(req.session.role!, req.session.userId);
    }

    res.json(activities);
  });

  // Get available brokers for student selection
  app.get("/api/brokers/available", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const brokers = await storage.getAllBrokers();
    const activeBrokers = brokers.filter(b => b.status === "Active");
    res.json(activeBrokers);
  });

  return httpServer;
}
