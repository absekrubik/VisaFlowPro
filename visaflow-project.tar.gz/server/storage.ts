import {
  connectToDatabase,
  getNextSequence,
  UserModel,
  BrokerModel,
  StudentModel,
  ApplicationModel,
  CommissionModel,
  DocumentModel,
  ActivityModel,
} from "./db";
import {
  type User,
  type InsertUser,
  type Broker,
  type InsertBroker,
  type Student,
  type InsertStudent,
  type Application,
  type InsertApplication,
  type Commission,
  type InsertCommission,
  type Document,
  type InsertDocument,
  type Activity,
  type InsertActivity,
} from "@shared/schema";

function toUser(doc: any): User | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    name: doc.name,
    email: doc.email,
    password: doc.password,
    role: doc.role,
    createdAt: doc.createdAt,
  };
}

function toBroker(doc: any): Broker | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    userId: doc.userId,
    commissionRate: doc.commissionRate,
    status: doc.status,
    activeStudents: doc.activeStudents,
    phone: doc.phone || null,
    address: doc.address || null,
    companyName: doc.companyName || null,
    licenseNumber: doc.licenseNumber || null,
  };
}

function toStudent(doc: any): Student | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    userId: doc.userId,
    brokerId: doc.brokerId || null,
    passportNumber: doc.passportNumber || null,
    dateOfBirth: doc.dateOfBirth || null,
    currentAddress: doc.currentAddress || null,
    phone: doc.phone || null,
    nationality: doc.nationality || null,
    education: doc.education || null,
  };
}

function toApplication(doc: any): Application | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    studentId: doc.studentId,
    visaType: doc.visaType,
    targetCountry: doc.targetCountry,
    purpose: doc.purpose || null,
    status: doc.status,
    progress: doc.progress,
    submittedAt: doc.submittedAt,
    lastAction: doc.lastAction || null,
  };
}

function toCommission(doc: any): Commission | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    brokerId: doc.brokerId,
    studentId: doc.studentId,
    amount: doc.amount,
    status: doc.status,
    date: doc.date,
  };
}

function toDocument(doc: any): Document | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    ownerType: doc.ownerType,
    ownerId: doc.ownerId,
    uploadedById: doc.uploadedById,
    name: doc.name,
    type: doc.type,
    path: doc.path,
    status: doc.status,
    notes: doc.notes || null,
    uploadedAt: doc.uploadedAt,
  };
}

function toActivity(doc: any): Activity | undefined {
  if (!doc) return undefined;
  return {
    id: doc.id,
    actorId: doc.actorId,
    actorRole: doc.actorRole,
    targetType: doc.targetType,
    targetId: doc.targetId,
    activityType: doc.activityType,
    description: doc.description,
    metadata: doc.metadata || null,
    createdAt: doc.createdAt,
  };
}

export interface IStorage {
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: number): Promise<User | undefined>;
  updateUserName(userId: number, name: string): Promise<void>;

  createBroker(broker: InsertBroker): Promise<Broker>;
  getBrokerByUserId(userId: number): Promise<Broker | undefined>;
  getAllBrokers(): Promise<Array<Broker & { user: User }>>;
  updateBrokerStatus(brokerId: number, status: string): Promise<void>;
  getBrokerById(id: number): Promise<Broker | undefined>;
  updateBrokerProfile(brokerId: number, data: Partial<Broker>): Promise<Broker>;
  updateBrokerCommissionRate(brokerId: number, rate: string): Promise<void>;

  createStudent(student: InsertStudent): Promise<Student>;
  getStudentByUserId(userId: number): Promise<Student | undefined>;
  getStudentsByBrokerId(brokerId: number): Promise<Array<Student & { user: User }>>;
  getAllStudents(): Promise<Array<Student & { user: User; broker?: Broker & { user: User } }>>;
  assignBrokerToStudent(studentId: number, brokerId: number): Promise<void>;
  updateStudentProfile(studentId: number, data: Partial<Student>): Promise<Student>;
  getStudentById(id: number): Promise<Student | undefined>;

  createApplication(application: InsertApplication): Promise<Application>;
  getApplicationsByStudentId(studentId: number): Promise<Application[]>;
  getApplicationsByBrokerId(brokerId: number): Promise<Array<Application & { student: Student & { user: User } }>>;
  getAllApplications(): Promise<Array<Application & { student: Student & { user: User } }>>;
  updateApplicationStatus(id: number, status: string): Promise<void>;
  updateApplicationProgress(id: number, progress: number, lastAction: string): Promise<void>;
  getApplicationById(id: number): Promise<Application | undefined>;

  createCommission(commission: InsertCommission): Promise<Commission>;
  getCommissionsByBrokerId(brokerId: number): Promise<Array<Commission & { student: Student & { user: User } }>>;
  getAllCommissions(): Promise<Array<Commission & { broker: Broker & { user: User }; student: Student & { user: User } }>>;
  updateCommissionStatus(id: number, status: string): Promise<void>;

  createDocument(document: InsertDocument): Promise<Document>;
  getDocumentsByOwner(ownerType: string, ownerId: number): Promise<Array<Document & { uploadedBy: User }>>;
  getDocumentsByBrokerStudents(brokerId: number): Promise<Array<Document & { uploadedBy: User }>>;
  getAllDocuments(): Promise<Array<Document & { uploadedBy: User }>>;
  updateDocumentStatus(id: number, status: string, notes?: string): Promise<void>;
  getDocumentById(id: number): Promise<Document | undefined>;

  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivitiesByRole(role: string, userId: number): Promise<Array<Activity & { actor: User }>>;
  getAllActivities(): Promise<Array<Activity & { actor: User }>>;
}

export class DatabaseStorage implements IStorage {
  private initialized = false;

  private async ensureConnected(): Promise<void> {
    if (!this.initialized) {
      await connectToDatabase();
      this.initialized = true;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    await this.ensureConnected();
    const user = await UserModel.findOne({ email }).lean();
    return toUser(user);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    await this.ensureConnected();
    const id = await getNextSequence("users");
    const user = await UserModel.create({
      id,
      ...insertUser,
      createdAt: new Date(),
    });
    return toUser(user)!;
  }

  async getUserById(id: number): Promise<User | undefined> {
    await this.ensureConnected();
    const user = await UserModel.findOne({ id }).lean();
    return toUser(user);
  }

  async updateUserName(userId: number, name: string): Promise<void> {
    await this.ensureConnected();
    await UserModel.updateOne({ id: userId }, { name });
  }

  async createBroker(insertBroker: InsertBroker): Promise<Broker> {
    await this.ensureConnected();
    const id = await getNextSequence("brokers");
    const broker = await BrokerModel.create({
      id,
      ...insertBroker,
      activeStudents: 0,
    });
    return toBroker(broker)!;
  }

  async getBrokerByUserId(userId: number): Promise<Broker | undefined> {
    await this.ensureConnected();
    const broker = await BrokerModel.findOne({ userId }).lean();
    return toBroker(broker);
  }

  async getAllBrokers(): Promise<Array<Broker & { user: User }>> {
    await this.ensureConnected();
    const brokerDocs = await BrokerModel.find().lean();
    const results: Array<Broker & { user: User }> = [];
    
    for (const brokerDoc of brokerDocs) {
      const userDoc = await UserModel.findOne({ id: brokerDoc.userId }).lean();
      if (userDoc) {
        results.push({
          ...toBroker(brokerDoc)!,
          user: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }

  async updateBrokerStatus(brokerId: number, status: string): Promise<void> {
    await this.ensureConnected();
    await BrokerModel.updateOne({ id: brokerId }, { status });
  }

  async getBrokerById(id: number): Promise<Broker | undefined> {
    await this.ensureConnected();
    const broker = await BrokerModel.findOne({ id }).lean();
    return toBroker(broker);
  }

  async updateBrokerProfile(brokerId: number, data: Partial<Broker>): Promise<Broker> {
    await this.ensureConnected();
    const broker = await BrokerModel.findOneAndUpdate(
      { id: brokerId },
      { $set: data },
      { new: true }
    ).lean();
    return toBroker(broker)!;
  }

  async updateBrokerCommissionRate(brokerId: number, rate: string): Promise<void> {
    await this.ensureConnected();
    await BrokerModel.updateOne({ id: brokerId }, { commissionRate: rate });
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    await this.ensureConnected();
    const id = await getNextSequence("students");
    const student = await StudentModel.create({
      id,
      ...insertStudent,
    });
    return toStudent(student)!;
  }

  async getStudentByUserId(userId: number): Promise<Student | undefined> {
    await this.ensureConnected();
    const student = await StudentModel.findOne({ userId }).lean();
    return toStudent(student);
  }

  async getStudentsByBrokerId(brokerId: number): Promise<Array<Student & { user: User }>> {
    await this.ensureConnected();
    const studentDocs = await StudentModel.find({ brokerId }).lean();
    const results: Array<Student & { user: User }> = [];
    
    for (const studentDoc of studentDocs) {
      const userDoc = await UserModel.findOne({ id: studentDoc.userId }).lean();
      if (userDoc) {
        results.push({
          ...toStudent(studentDoc)!,
          user: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }

  async getAllStudents(): Promise<Array<Student & { user: User; broker?: Broker & { user: User } }>> {
    await this.ensureConnected();
    const studentDocs = await StudentModel.find().lean();
    const results: Array<Student & { user: User; broker?: Broker & { user: User } }> = [];
    
    for (const studentDoc of studentDocs) {
      const userDoc = await UserModel.findOne({ id: studentDoc.userId }).lean();
      if (userDoc) {
        let brokerWithUser: (Broker & { user: User }) | undefined;
        
        if (studentDoc.brokerId) {
          const brokerDoc = await BrokerModel.findOne({ id: studentDoc.brokerId }).lean();
          if (brokerDoc) {
            const brokerUserDoc = await UserModel.findOne({ id: brokerDoc.userId }).lean();
            if (brokerUserDoc) {
              brokerWithUser = {
                ...toBroker(brokerDoc)!,
                user: toUser(brokerUserDoc)!,
              };
            }
          }
        }
        
        results.push({
          ...toStudent(studentDoc)!,
          user: toUser(userDoc)!,
          broker: brokerWithUser,
        });
      }
    }
    
    return results;
  }

  async assignBrokerToStudent(studentId: number, brokerId: number): Promise<void> {
    await this.ensureConnected();
    await StudentModel.updateOne({ id: studentId }, { brokerId });
  }

  async updateStudentProfile(studentId: number, data: Partial<Student>): Promise<Student> {
    await this.ensureConnected();
    const student = await StudentModel.findOneAndUpdate(
      { id: studentId },
      { $set: data },
      { new: true }
    ).lean();
    return toStudent(student)!;
  }

  async getStudentById(id: number): Promise<Student | undefined> {
    await this.ensureConnected();
    const student = await StudentModel.findOne({ id }).lean();
    return toStudent(student);
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    await this.ensureConnected();
    const id = await getNextSequence("applications");
    const application = await ApplicationModel.create({
      id,
      ...insertApplication,
      submittedAt: new Date(),
    });
    return toApplication(application)!;
  }

  async getApplicationsByStudentId(studentId: number): Promise<Application[]> {
    await this.ensureConnected();
    const applications = await ApplicationModel.find({ studentId }).lean();
    return applications.map(app => toApplication(app)!);
  }

  async getApplicationsByBrokerId(brokerId: number): Promise<Array<Application & { student: Student & { user: User } }>> {
    await this.ensureConnected();
    const studentDocs = await StudentModel.find({ brokerId }).lean();
    const studentIds = studentDocs.map(s => s.id);
    
    if (studentIds.length === 0) {
      return [];
    }
    
    const applicationDocs = await ApplicationModel.find({ studentId: { $in: studentIds } })
      .sort({ submittedAt: -1 })
      .lean();
    
    const results: Array<Application & { student: Student & { user: User } }> = [];
    
    for (const appDoc of applicationDocs) {
      const studentDoc = studentDocs.find(s => s.id === appDoc.studentId);
      if (studentDoc) {
        const userDoc = await UserModel.findOne({ id: studentDoc.userId }).lean();
        if (userDoc) {
          results.push({
            ...toApplication(appDoc)!,
            student: {
              ...toStudent(studentDoc)!,
              user: toUser(userDoc)!,
            },
          });
        }
      }
    }
    
    return results;
  }

  async getAllApplications(): Promise<Array<Application & { student: Student & { user: User } }>> {
    await this.ensureConnected();
    const applicationDocs = await ApplicationModel.find().sort({ submittedAt: -1 }).lean();
    const results: Array<Application & { student: Student & { user: User } }> = [];
    
    for (const appDoc of applicationDocs) {
      const studentDoc = await StudentModel.findOne({ id: appDoc.studentId }).lean();
      if (studentDoc) {
        const userDoc = await UserModel.findOne({ id: studentDoc.userId }).lean();
        if (userDoc) {
          results.push({
            ...toApplication(appDoc)!,
            student: {
              ...toStudent(studentDoc)!,
              user: toUser(userDoc)!,
            },
          });
        }
      }
    }
    
    return results;
  }

  async updateApplicationStatus(id: number, status: string): Promise<void> {
    await this.ensureConnected();
    await ApplicationModel.updateOne({ id }, { status });
  }

  async updateApplicationProgress(id: number, progress: number, lastAction: string): Promise<void> {
    await this.ensureConnected();
    await ApplicationModel.updateOne({ id }, { progress, lastAction });
  }

  async getApplicationById(id: number): Promise<Application | undefined> {
    await this.ensureConnected();
    const application = await ApplicationModel.findOne({ id }).lean();
    return toApplication(application);
  }

  async createCommission(insertCommission: InsertCommission): Promise<Commission> {
    await this.ensureConnected();
    const id = await getNextSequence("commissions");
    const commission = await CommissionModel.create({
      id,
      ...insertCommission,
      date: new Date(),
    });
    return toCommission(commission)!;
  }

  async getCommissionsByBrokerId(brokerId: number): Promise<Array<Commission & { student: Student & { user: User } }>> {
    await this.ensureConnected();
    const commissionDocs = await CommissionModel.find({ brokerId }).sort({ date: -1 }).lean();
    const results: Array<Commission & { student: Student & { user: User } }> = [];
    
    for (const commDoc of commissionDocs) {
      const studentDoc = await StudentModel.findOne({ id: commDoc.studentId }).lean();
      if (studentDoc) {
        const userDoc = await UserModel.findOne({ id: studentDoc.userId }).lean();
        if (userDoc) {
          results.push({
            ...toCommission(commDoc)!,
            student: {
              ...toStudent(studentDoc)!,
              user: toUser(userDoc)!,
            },
          });
        }
      }
    }
    
    return results;
  }

  async getAllCommissions(): Promise<Array<Commission & { broker: Broker & { user: User }; student: Student & { user: User } }>> {
    await this.ensureConnected();
    const commissionDocs = await CommissionModel.find().sort({ date: -1 }).lean();
    const results: Array<Commission & { broker: Broker & { user: User }; student: Student & { user: User } }> = [];
    
    for (const commDoc of commissionDocs) {
      const brokerDoc = await BrokerModel.findOne({ id: commDoc.brokerId }).lean();
      const studentDoc = await StudentModel.findOne({ id: commDoc.studentId }).lean();
      
      if (brokerDoc && studentDoc) {
        const brokerUserDoc = await UserModel.findOne({ id: brokerDoc.userId }).lean();
        const studentUserDoc = await UserModel.findOne({ id: studentDoc.userId }).lean();
        
        if (brokerUserDoc && studentUserDoc) {
          results.push({
            ...toCommission(commDoc)!,
            broker: {
              ...toBroker(brokerDoc)!,
              user: toUser(brokerUserDoc)!,
            },
            student: {
              ...toStudent(studentDoc)!,
              user: toUser(studentUserDoc)!,
            },
          });
        }
      }
    }
    
    return results;
  }

  async updateCommissionStatus(id: number, status: string): Promise<void> {
    await this.ensureConnected();
    await CommissionModel.updateOne({ id }, { status });
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    await this.ensureConnected();
    const id = await getNextSequence("documents");
    const document = await DocumentModel.create({
      id,
      ...insertDocument,
      uploadedAt: new Date(),
    });
    return toDocument(document)!;
  }

  async getDocumentsByOwner(ownerType: string, ownerId: number): Promise<Array<Document & { uploadedBy: User }>> {
    await this.ensureConnected();
    const documentDocs = await DocumentModel.find({ ownerType, ownerId }).sort({ uploadedAt: -1 }).lean();
    const results: Array<Document & { uploadedBy: User }> = [];
    
    for (const docDoc of documentDocs) {
      const userDoc = await UserModel.findOne({ id: docDoc.uploadedById }).lean();
      if (userDoc) {
        results.push({
          ...toDocument(docDoc)!,
          uploadedBy: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }

  async getDocumentsByBrokerStudents(brokerId: number): Promise<Array<Document & { uploadedBy: User }>> {
    await this.ensureConnected();
    const studentDocs = await StudentModel.find({ brokerId }).lean();
    const studentIds = studentDocs.map(s => s.id);
    
    if (studentIds.length === 0) {
      return [];
    }
    
    const documentDocs = await DocumentModel.find({
      ownerType: "student",
      ownerId: { $in: studentIds },
    }).sort({ uploadedAt: -1 }).lean();
    
    const results: Array<Document & { uploadedBy: User }> = [];
    
    for (const docDoc of documentDocs) {
      const userDoc = await UserModel.findOne({ id: docDoc.uploadedById }).lean();
      if (userDoc) {
        results.push({
          ...toDocument(docDoc)!,
          uploadedBy: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }

  async getAllDocuments(): Promise<Array<Document & { uploadedBy: User }>> {
    await this.ensureConnected();
    const documentDocs = await DocumentModel.find().sort({ uploadedAt: -1 }).lean();
    const results: Array<Document & { uploadedBy: User }> = [];
    
    for (const docDoc of documentDocs) {
      const userDoc = await UserModel.findOne({ id: docDoc.uploadedById }).lean();
      if (userDoc) {
        results.push({
          ...toDocument(docDoc)!,
          uploadedBy: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }

  async updateDocumentStatus(id: number, status: string, notes?: string): Promise<void> {
    await this.ensureConnected();
    const updateData: any = { status };
    if (notes !== undefined) {
      updateData.notes = notes;
    }
    await DocumentModel.updateOne({ id }, updateData);
  }

  async getDocumentById(id: number): Promise<Document | undefined> {
    await this.ensureConnected();
    const document = await DocumentModel.findOne({ id }).lean();
    return toDocument(document);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    await this.ensureConnected();
    const id = await getNextSequence("activities");
    const activity = await ActivityModel.create({
      id,
      ...insertActivity,
      createdAt: new Date(),
    });
    return toActivity(activity)!;
  }

  async getActivitiesByRole(role: string, userId: number): Promise<Array<Activity & { actor: User }>> {
    await this.ensureConnected();
    const activityDocs = await ActivityModel.find()
      .sort({ createdAt: -1 })
      .limit(50)
      .lean();
    
    const results: Array<Activity & { actor: User }> = [];
    
    for (const actDoc of activityDocs) {
      const userDoc = await UserModel.findOne({ id: actDoc.actorId }).lean();
      if (userDoc) {
        results.push({
          ...toActivity(actDoc)!,
          actor: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }

  async getAllActivities(): Promise<Array<Activity & { actor: User }>> {
    await this.ensureConnected();
    const activityDocs = await ActivityModel.find()
      .sort({ createdAt: -1 })
      .limit(100)
      .lean();
    
    const results: Array<Activity & { actor: User }> = [];
    
    for (const actDoc of activityDocs) {
      const userDoc = await UserModel.findOne({ id: actDoc.actorId }).lean();
      if (userDoc) {
        results.push({
          ...toActivity(actDoc)!,
          actor: toUser(userDoc)!,
        });
      }
    }
    
    return results;
  }
}

export const storage = new DatabaseStorage();
